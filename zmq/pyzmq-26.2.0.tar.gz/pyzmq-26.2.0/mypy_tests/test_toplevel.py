import zmq

zmq.has("feature")
public, secret = zmq.curve_keypair()
